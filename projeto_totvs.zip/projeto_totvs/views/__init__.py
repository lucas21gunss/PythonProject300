from .routes import init_routes

__all__ = ['init_routes']
