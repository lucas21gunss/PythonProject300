from .projeto_controller import ProjetoController

__all__ = ['ProjetoController']
