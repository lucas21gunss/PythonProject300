from .projeto_model import ProjetoModel

__all__ = ['ProjetoModel']
